from datetime import datetime

from calibre import prints
from calibre.gui2.actions import InterfaceAction
from qt.core import (QMenu, QTimer, QDialog, QVBoxLayout, QLabel, QTimeEdit,
                     QDialogButtonBox, QTime, QToolButton)
from calibre_plugins.goodreads_progress_auto_sync.config import prefs

try:
    load_translations()
except NameError:
    pass


MIN_PROGRESS = 1
CLOCK_CHECK_MS = 30 * 1000


class GoodreadsProgressAutoSyncAction(InterfaceAction):
    name = 'Goodreads Progress Auto Sync'

    # This is the action Calibre exposes in Preferences > Toolbars & menus.
    action_spec = (
        _('Sync Goodreads Progress'),
        'images/icon.png',
        _('Sync Calibre E-book Viewer progress to Goodreads now'),
        None,
    )

    # Make this a normal toolbar action and also give it a small drop-down menu.
    action_type = 'current'
    action_add_menu = True
    popup_type = QToolButton.MenuButtonPopup
    dont_add_to = frozenset()
    dont_remove_from = frozenset()

    def genesis(self):
        self.qaction.setToolTip(
            _('Sync Calibre E-book Viewer progress to Goodreads now')
        )
        self.qaction.triggered.connect(self.sync_all)

        self.menu = QMenu(self.gui)
        self.qaction.setMenu(self.menu)

        sync_now = self.menu.addAction(_('Sync now'))
        sync_now.triggered.connect(self.sync_all)

        set_time = self.menu.addAction(_('Set automatic sync time...'))
        set_time.triggered.connect(self._set_sync_time_dialog)

        self.menu.addSeparator()

        about = self.menu.addAction(_('Automatic sync schedule'))
        about.triggered.connect(self._show_about)

        self._last_run_date = None
        self._clock_timer = QTimer(self.gui)
        self._clock_timer.timeout.connect(self._check_clock)

    def initialization_complete(self):
        self.reload_settings()
        self._clock_timer.start(CLOCK_CHECK_MS)

    def reload_settings(self):
        self.sync_time = prefs.get('sync_time', '23:00')
        if not isinstance(self.sync_time, str) or ':' not in self.sync_time:
            self.sync_time = '23:00'
        try:
            self._sync_hour, self._sync_minute = [int(x) for x in self.sync_time.split(':', 1)]
        except Exception:
            self._sync_hour, self._sync_minute = 23, 0
            self.sync_time = '23:00'

    def shutting_down(self):
        try:
            self._clock_timer.stop()
        except Exception:
            pass

    def _set_sync_time_dialog(self):
        d = QDialog(self.gui)
        d.setWindowTitle(_('Automatic Goodreads sync time'))

        layout = QVBoxLayout(d)

        label = QLabel(
            _('Choose the daily time for automatic Goodreads progress sync. '
              'Calibre must be running at that time.')
        )
        label.setWordWrap(True)
        layout.addWidget(label)

        time_edit = QTimeEdit()
        time_edit.setDisplayFormat('h:mm AP')
        current = QTime(self._sync_hour, self._sync_minute)
        time_edit.setTime(current)
        layout.addWidget(time_edit)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(d.accept)
        buttons.rejected.connect(d.reject)
        layout.addWidget(buttons)

        if d.exec() == QDialog.DialogCode.Accepted:
            value = time_edit.time().toString('HH:mm')
            prefs['sync_time'] = value
            self.reload_settings()
            self._status(
                _('Automatic Goodreads sync time set to %s') %
                self._display_sync_time()
            )

    def _show_about(self):
        from calibre.gui2 import info_dialog
        info_dialog(
            self.gui,
            _('Goodreads Progress Auto Sync'),
            _(
                'Click the toolbar button to sync immediately. '
                'Automatic sync is currently scheduled for %s while Calibre is running. '
                'You can change it from this toolbar menu or from '
                'Preferences → Plugins → Goodreads Progress Auto Sync → Customize plugin.' % self._display_sync_time()
            ),
            show=True,
        )

    def _display_sync_time(self):
        try:
            hour = self._sync_hour
            minute = self._sync_minute
            suffix = 'AM' if hour < 12 else 'PM'
            display_hour = hour % 12 or 12
            return f'{display_hour}:{minute:02d} {suffix}'
        except Exception:
            return self.sync_time

    def _check_clock(self):
        now = datetime.now()
        today = now.date().isoformat()
        if (
            now.hour == self._sync_hour
            and now.minute == self._sync_minute
            and self._last_run_date != today
        ):
            self._last_run_date = today
            self.sync_all()

    def _status(self, message, timeout=10000):
        try:
            self.gui.status_bar.showMessage(message, timeout)
        except TypeError:
            self.gui.status_bar.showMessage(message)

    def _goodreads_plugin(self):
        return self.gui.iactions.get('Goodreads Sync')

    def _viewer_percent(self, db, book_id):
        try:
            mi = db.new_api.get_proxy_metadata(book_id)
            formatter = self.gui.library_view.model().formatter
            template = '{id:reading_progress(local,percent_number)}'
            value = formatter.safe_format(
                template, mi, '', mi,
                column_name='goodreads_progress_auto_sync'
            )
            if value is None:
                return None
            value = str(value).strip()
            if not value:
                return None

            pct = int(round(float(value)))
            return max(0, min(100, pct))
        except Exception as err:
            prints(
                'Goodreads Progress Auto Sync: unable to read viewer progress '
                f'for calibre book {book_id}: {err}'
            )
            return None

    def sync_all(self):
        gr = self._goodreads_plugin()
        if gr is None:
            self._status(
                'Goodreads Progress Auto Sync: Goodreads Sync plugin is not loaded.'
            )
            return

        try:
            import calibre_plugins.goodreads_sync.config as cfg
        except Exception as err:
            self._status(
                'Goodreads Progress Auto Sync: cannot import Goodreads Sync.'
            )
            prints('Goodreads Progress Auto Sync:', err)
            return

        users = cfg.plugin_prefs.get(cfg.STORE_USERS, {})
        if not users:
            self._status(
                'Goodreads Progress Auto Sync: configure/authorize Goodreads Sync first.'
            )
            return

        if len(users) != 1:
            self._status(
                'Goodreads Progress Auto Sync: multiple Goodreads users are configured; '
                'this helper currently requires exactly one.'
            )
            return

        user_name = next(iter(users))

        gr_settings = cfg.plugin_prefs.get(cfg.STORE_PLUGIN, {})
        progress_column = gr_settings.get(cfg.KEY_READING_PROGRESS_COLUMN, '')
        if not progress_column:
            self._status(
                'Goodreads Progress Auto Sync: choose a numeric Reading progress '
                'column in Goodreads Sync settings first.'
            )
            return

        db = self.gui.library_view.model().db

        try:
            client = gr.grhttp.create_oauth_client(user_name)
        except Exception as err:
            self._status(
                'Goodreads Progress Auto Sync: failed to create Goodreads connection.'
            )
            prints('Goodreads Progress Auto Sync: OAuth client error:', err)
            return

        updates_for_column = {}
        changed_ids = []
        sent = 0
        skipped_no_progress = 0
        skipped_unlinked = 0
        unchanged = 0
        failed = 0

        try:
            book_ids = sorted(db.new_api.all_book_ids())
        except Exception:
            book_ids = sorted(db.all_ids())

        for book_id in book_ids:
            pct = self._viewer_percent(db, book_id)
            if pct is None or pct < MIN_PROGRESS:
                skipped_no_progress += 1
                continue

            try:
                identifiers = db.get_identifiers(book_id, index_is_id=True) or {}
            except Exception:
                try:
                    identifiers = db.new_api.field_for('identifiers', book_id) or {}
                except Exception:
                    identifiers = {}

            goodreads_id = identifiers.get('goodreads')
            if not goodreads_id:
                skipped_unlinked += 1
                continue

            try:
                last_synced = db.new_api.field_for(progress_column, book_id)
            except Exception:
                last_synced = None

            try:
                last_synced_num = (
                    None if last_synced in (None, '')
                    else int(round(float(last_synced)))
                )
            except Exception:
                last_synced_num = None

            if last_synced_num == pct:
                unchanged += 1
                continue

            try:
                ok = gr.grhttp.update_status(
                    client,
                    goodreads_id,
                    reading_progress=pct,
                    progress_is_percent=True,
                    comment=None,
                )
            except Exception as err:
                ok = False
                prints(
                    'Goodreads Progress Auto Sync: Goodreads update failed for '
                    f'book {book_id} / Goodreads {goodreads_id}: {err}'
                )

            if ok:
                sent += 1
                updates_for_column[book_id] = pct
                changed_ids.append(book_id)
            else:
                failed += 1

        if updates_for_column:
            try:
                db.new_api.set_field(progress_column, updates_for_column)
            except Exception as err:
                prints(
                    'Goodreads Progress Auto Sync: progress was sent to Goodreads '
                    f'but Calibre column update failed: {err}'
                )
                self._status(
                    f'Goodreads: sent {sent}; warning: could not update '
                    f'{progress_column} in Calibre.'
                )
                return

            try:
                self.gui.library_view.model().refresh_ids(changed_ids)
            except Exception:
                pass

        self._status(
            'Goodreads progress sync: '
            f'{sent} sent, {unchanged} unchanged, {failed} failed. '
            f'{skipped_unlinked} unlinked books skipped.'
        )
