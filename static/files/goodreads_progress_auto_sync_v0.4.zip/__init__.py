from calibre.customize import InterfaceActionBase


class GoodreadsProgressAutoSyncBase(InterfaceActionBase):
    name = 'Goodreads Progress Auto Sync'
    description = 'Silently sync Calibre E-book Viewer reading progress to Goodreads.'
    supported_platforms = ['windows', 'osx', 'linux']
    author = 'Custom helper plugin'
    version = (0, 4, 0)
    minimum_calibre_version = (9, 5, 0)
    actual_plugin = 'calibre_plugins.goodreads_progress_auto_sync.action:GoodreadsProgressAutoSyncAction'
    can_be_disabled = True

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.goodreads_progress_auto_sync.config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.save_settings()
        # Refresh the already-loaded GUI action, if possible.
        try:
            ia = self.actual_plugin_
            if ia is not None and hasattr(ia, 'reload_settings'):
                ia.reload_settings()
        except Exception:
            pass
