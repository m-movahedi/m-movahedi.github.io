Goodreads Progress Auto Sync v0.4
==================================

Changes in v0.4
---------------
- Fixes Calibre's "Customize plugin" support by implementing
  is_customizable() as the required method.
- Adds "Set automatic sync time..." directly to the toolbar button's
  drop-down menu.
- Keeps "Sync now" for immediate testing.

Install / update
----------------
1. Preferences > Plugins > Load plugin from file
2. Select this ZIP
3. Allow Calibre to replace the existing version if prompted
4. Restart Calibre

Set the sync time from Preferences
----------------------------------
Preferences > Plugins > Goodreads Progress Auto Sync > Customize plugin

You should now see:
    Daily sync time: [time picker]

Set the sync time from the toolbar
----------------------------------
Use the drop-down arrow beside "Sync Goodreads Progress", then choose:
    Set automatic sync time...

Toolbar
-------
If the button is not already visible:
Preferences > Toolbars & menus > The main toolbar
Add:
    Sync Goodreads Progress

The main button runs a sync immediately. The drop-down menu contains:
- Sync now
- Set automatic sync time...
- Automatic sync schedule

Default automatic time: 11:00 PM.
Calibre must be running at the scheduled time.
