from calibre.utils.config import JSONConfig
from qt.core import QWidget, QVBoxLayout, QFormLayout, QTimeEdit, QTime, QLabel

prefs = JSONConfig('plugins/goodreads_progress_auto_sync')
prefs.defaults['sync_time'] = '23:00'


class ConfigWidget(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout(self)

        title = QLabel('<b>Automatic Goodreads progress sync</b>')
        layout.addWidget(title)

        note = QLabel(
            'Choose the time Calibre should automatically send your saved '
            'E-book Viewer reading progress to Goodreads each day. '
            'Calibre must be running at the scheduled time.'
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        form = QFormLayout()
        self.sync_time = QTimeEdit()
        self.sync_time.setDisplayFormat('h:mm AP')
        self.sync_time.setCalendarPopup(False)

        stored = prefs.get('sync_time', '23:00')
        qtime = QTime.fromString(stored, 'HH:mm')
        if not qtime.isValid():
            qtime = QTime(23, 0)
        self.sync_time.setTime(qtime)

        form.addRow('Daily sync time:', self.sync_time)
        layout.addLayout(form)
        layout.addStretch(1)

    def save_settings(self):
        prefs['sync_time'] = self.sync_time.time().toString('HH:mm')
