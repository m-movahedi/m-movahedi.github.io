import re
from datetime import datetime, timezone

from calibre.gui2 import info_dialog, question_dialog
from calibre.gui2.actions import InterfaceAction
from qt.core import (
    QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMenu, QPushButton, Qt, QTimer, QVBoxLayout,
)

# The app's reading columns (lib/columns.dart): lookup name, title, Calibre type.
COLUMNS = [
    ('my_rating', 'Rating', 'rating'),
    ('finished', 'Finished', 'bool'),
    ('up_next', 'Up next', 'bool'),
    ('progress', 'Progress (%)', 'float'),
    ('date_started', 'Start date', 'datetime'),
    ('date_finished', 'Finish date', 'datetime'),
    ('days_read', 'Days read', 'int'),
    ('read_time', 'Read time (min)', 'int'),
    ('avg_minutes', 'Average min / day', 'int'),
    ('date_last_read', 'Last read', 'datetime'),
    ('currently_reading', 'Currently reading', 'bool'),
]

READING = 'currently_reading'


def currently_reading(progress, finished, last_read, now=None):
    """At least 10% read, read in the last 30 days, and not finished (the app's rule too)."""
    if last_read is None or finished or (progress or 0) < 10:
        return False
    now = now or datetime.now(timezone.utc)
    if last_read.tzinfo is None:
        last_read = last_read.replace(tzinfo=timezone.utc)
    return (now.date() - last_read.astimezone(now.tzinfo).date()).days <= 30


def update_currently_reading(db, now=None):
    """Works out every "Currently reading" column (shared and each person's) from the same
    person's progress, finished and last-read columns. [db] is calibre's new_api. Returns the
    ids of books that changed."""
    keys = set(db.field_metadata.custom_field_keys())
    changed = set()
    ids = db.all_book_ids()
    for key in keys:
        if not key.startswith('#' + READING):
            continue
        suffix = key[len('#' + READING):]  # '' or '_<person>'
        def values(name):
            field = f'#{name}{suffix}'
            return db.all_field_for(field, ids) if field in keys else {}
        progress, finished, last = values('progress'), values('finished'), values('date_last_read')
        current = db.all_field_for(key, ids)
        updates = {}
        for book in ids:
            reading = currently_reading(progress.get(book), finished.get(book), last.get(book), now)
            if reading != bool(current.get(book)):  # empty counts as "no": no writes for unread books
                updates[book] = reading
        if updates:
            db.set_field(key, updates)
            changed.update(updates)
    return changed

SHARED = ''  # the list entry for columns without a name


def column_user(name):
    """A person's name as the app puts it in lookup names: "Sara K." -> "sara_k"."""
    name = re.sub(r'[^a-z0-9_]+', '_', name.lower())
    return re.sub(r'_+', '_', name).strip('_')


def wanted_columns(people):
    """(lookup name, title, type) for everyone chosen; SHARED means no name added."""
    for person in people:
        user = column_user(person)
        for name, title, datatype in COLUMNS:
            if user:
                yield f'{name}_{user}', f'{title} ({person})', datatype
            else:
                yield name, title, datatype


def server_users():
    """The content server's users (Preferences -> Sharing over the net -> Users)."""
    try:
        from calibre.srv.users import UserManager
        return sorted(UserManager().all_user_names)
    except Exception:
        return []


class ColumnsDialog(QDialog):
    def __init__(self, parent, users):
        super().__init__(parent)
        self.setWindowTitle('Start Reading! columns')
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            'Who reads with Start Reading!? Each person chosen gets their own columns '
            '(e.g. #progress_sara), matching "Personal columns" in the app.\n'
            '"Shared" makes one set for everybody (#progress).'))
        self.people = QListWidget(self)
        for person in [SHARED, *users]:
            self._add(person, checked=person != SHARED or not users)
        layout.addWidget(self.people)
        row = QHBoxLayout()
        self.name = QLineEdit(self)
        self.name.setPlaceholderText('Another name (as their Calibre login)')
        add = QPushButton('Add', self)
        add.clicked.connect(self._add_typed)
        row.addWidget(self.name)
        row.addWidget(add)
        layout.addLayout(row)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, self)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Create columns')
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.resize(460, 380)

    def _add(self, person, checked=True):
        item = QListWidgetItem('Shared (no name)' if person == SHARED else person, self.people)
        item.setData(Qt.ItemDataRole.UserRole, person)
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        item.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)

    def _add_typed(self):
        person = self.name.text().strip()
        if column_user(person):
            self._add(person)
            self.name.clear()

    def chosen(self):
        return [self.people.item(i).data(Qt.ItemDataRole.UserRole)
                for i in range(self.people.count())
                if self.people.item(i).checkState() == Qt.CheckState.Checked]


class StartReadingColumnsAction(InterfaceAction):
    name = 'Start Reading! columns'
    action_spec = ('Start Reading! columns', None,
                   'Create the reading columns the Start Reading! app syncs with', None)
    action_type = 'current'

    def genesis(self):
        self.qaction.triggered.connect(self.create_columns)
        menu = QMenu(self.gui)
        menu.addAction('Create columns…', self.create_columns)
        menu.addAction('Update "Currently reading" now', lambda: self.update_reading(report=True))
        self.qaction.setMenu(menu)
        # Books stop being "currently reading" 30 days after they were last read, even if no device
        # syncs: worked out when calibre starts, when the library changes, and every 6 hours.
        self.timer = QTimer(self.gui)
        self.timer.timeout.connect(self.update_reading)
        self.timer.start(6 * 60 * 60 * 1000)

    def initialization_complete(self):
        self.update_reading()

    def library_changed(self, db):
        self.update_reading()

    def update_reading(self, report=False):
        try:
            changed = update_currently_reading(self.gui.current_db.new_api)
        except Exception as e:
            if report:
                info_dialog(self.gui, 'Start Reading! columns', f'Couldn’t update: {e}', show=True)
            return
        if changed:
            self.gui.library_view.model().refresh_ids(list(changed))
        if report:
            info_dialog(self.gui, 'Start Reading! columns',
                        f'Updated {len(changed)} books.' if changed else 'Everything is up to date.',
                        show=True)

    def create_columns(self):
        dialog = ColumnsDialog(self.gui, server_users())
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        db = self.gui.current_db
        existing = set(db.custom_field_keys())
        made = []
        for name, title, datatype in wanted_columns(dialog.chosen()):
            if '#' + name in existing:
                continue
            display = {'allow_half_stars': True} if datatype == 'rating' else {}
            db.create_custom_column(name, title, datatype, False, display=display)
            made.append('#' + name)
        if not made:
            info_dialog(self.gui, 'Start Reading! columns',
                        'All these columns already exist.', show=True)
            return
        if question_dialog(self.gui, 'Restart calibre',
                           f'Created {len(made)} columns:\n' + ', '.join(made) +
                           '\n\ncalibre needs a restart before they can be used. Restart now?'):
            self.gui.quit(restart=True)
