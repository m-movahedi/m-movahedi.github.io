"""Start Reading! columns: creates the custom columns the Start Reading! app syncs reading data
with (progress, finished, dates, reading time…), shared or one set per content-server user."""

from calibre.customize import InterfaceActionBase


class StartReadingColumnsPlugin(InterfaceActionBase):
    name = 'Start Reading! columns'
    description = ('Creates the reading columns the Start Reading! app syncs with: '
                   'shared, or one set per person in the household.')
    supported_platforms = ['windows', 'osx', 'linux']
    author = 'Mohammad Movahedi'
    version = (1, 1, 0)
    minimum_calibre_version = (6, 0, 0)
    actual_plugin = 'calibre_plugins.start_reading_columns.ui:StartReadingColumnsAction'
